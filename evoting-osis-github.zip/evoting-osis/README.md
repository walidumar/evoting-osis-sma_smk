# E-Voting Pemilihan Ketua OSIS

Aplikasi web untuk pelaksanaan pemilihan Ketua OSIS secara online: login siswa (NISN) & guru/staf (NIP bagi yang sudah memiliki, atau NUPTK bagi yang belum), voting anti-double-vote, realcount live untuk layar TV/LCD, dashboard admin, import DPT massal (CSV/XLSX), dan audit log.

Stack: **Node.js + Express 5 + SQLite (better-sqlite3)**, frontend HTML/JS vanilla + Tailwind (CDN) + Chart.js (CDN). Tidak butuh database server terpisah — cocok untuk deployment di satu server sekolah/lab tanpa infrastruktur tambahan.

---

## 1. Arsitektur

```
┌─────────────┐      HTTPS (Nginx reverse proxy, disarankan)
│  Browser /  │◄───────────────────────────────────┐
│  Layar TV   │                                     │
└─────────────┘                                     │
                                                     ▼
                                          ┌─────────────────────┐
                                          │   Node.js / Express   │
                                          │  (src/server.js)      │
                                          │  - session (cookie)   │
                                          │  - CSRF double-submit │
                                          │  - rate limiting      │
                                          └──────────┬───────────┘
                                                     │
                                          ┌──────────▼───────────┐
                                          │   SQLite (WAL mode)   │
                                          │   data/evoting.db     │
                                          │   data/sessions.sqlite│
                                          └───────────────────────┘
                                                     │
                                          ┌──────────▼───────────┐
                                          │ uploads/photos/*.webp │
                                          └───────────────────────┘
```

Struktur folder penting:
```
src/
  server.js          -> entry point, wiring middleware & routes
  db/init.js         -> skema tabel + seed admin default
  routes/            -> public.js, authVoter.js, admin.js
  middleware/         -> auth.js, csrf.js, rateLimit.js
  utils/              -> importParser.js, photoUpload.js, audit.js
public/               -> semua halaman frontend (statis)
data/                 -> evoting.db, sessions.sqlite (JANGAN di-commit ke git)
uploads/photos/       -> foto paslon hasil upload
```

---

## 2. Prasyarat

- Node.js 18 LTS atau lebih baru (dikembangkan & diuji dengan Node 22)
- npm
- Untuk production: reverse proxy dengan TLS (Nginx/Caddy) — aplikasi ini **tidak** menyediakan HTTPS sendiri

## 3. Instalasi & Menjalankan (Lab / Development)

```bash
npm install
cp .env.example .env
# edit .env: minimal ganti SESSION_SECRET
npm start
```

Server berjalan di `http://localhost:3000`. Saat pertama kali dijalankan (database masih kosong), akun admin default otomatis dibuat dan **dicetak di log terminal**:

```
username: admin
password: GantiSegera123!   <- SEGERA GANTI setelah login pertama (menu Pengaturan)
```

### Verifikasi instalasi berhasil
1. Buka `http://localhost:3000/index.html` → harus tampil landing page dengan status "BELUM DIMULAI".
2. Buka `http://localhost:3000/admin/login.html` → login dengan akun default di atas.
3. Login berhasil → diarahkan ke Dashboard, semua angka menunjukkan 0.

Jika langkah di atas gagal, lihat bagian **Troubleshooting**.

---

## 4. Alur Kerja Standar (untuk panitia pemilihan)

1. **Pengaturan** → isi nama sekolah, nama pemilihan, tahun pelajaran. Status tetap "Belum Dimulai".
2. **Paslon** → tambahkan minimal 2 paslon (nomor urut, nama ketua/wakil, foto, visi/misi).
3. **Import Data** → upload file DPT:
   - Jika file terpisah per jenis (siswa/guru) dengan header `NISN|Nama|Kelas|Jurusan` atau `NIP_atau_NUPTK|Nama|NIP|Jabatan`, pilih mode **IMPORT DATA SISWA** / **IMPORT DATA GURU**.
   - Jika file berupa satu sheet gabungan (format `NO, NAMA, NISN/NIK, KELAS/jabatan` — seperti file DPT yang pernah diberikan), pilih mode **FORMAT GABUNGAN (Auto-Deteksi)**.
   - Selalu cek pratinjau (jumlah valid/invalid, baris bermasalah) sebelum klik "Konfirmasi & Simpan".
4. Saat hari-H, ubah **Status Pemilihan** menjadi "Sedang Berlangsung" di menu Pengaturan. Login siswa/guru hanya diterima saat status ini aktif.
5. Tampilkan `/realcount.html` di layar TV/LCD (auto-refresh 10 detik, tanpa reload).
6. Setelah selesai, ubah status ke "Selesai" agar login pemilih otomatis ditolak.

---

## 5. Script Pemeliharaan (Maintenance)

Untuk operasi berulang seperti reset data voting atau reset password admin, **gunakan script di folder `scripts/`, bukan perintah `node -e "..."` ad-hoc**. Script-script ini memuat `.env` terlebih dahulu, sehingga selalu konsisten membaca `DB_PATH` yang sama dengan yang dipakai `server.js` saat berjalan — perintah ad-hoc yang tidak memuat `.env` berisiko menulis ke file database yang berbeda dari yang dibaca aplikasi kalau Anda memakai `DB_PATH` custom.

### Reset data voting (kembalikan semua ke 0)
```bash
npm run reset-votes                          # interaktif, minta konfirmasi ketik "RESET"
npm run reset-votes -- --yes                 # non-interaktif (untuk otomasi/cron)
npm run reset-votes -- --yes --status-belum-dimulai   # sekalian set status ke "Belum Dimulai"
```
Script ini otomatis: (1) menampilkan kondisi saat ini, (2) membuat backup `.db` sebelum mengubah apa pun, (3) menjalankan reset dalam satu transaksi, (4) menampilkan hasil verifikasi. **Tidak** menyentuh data siswa/guru/paslon, hanya status `has_voted` dan isi tabel `votes`.

### Reset password admin
```bash
npm run reset-password -- admin PasswordBaruAnda123!
```

### Backup database manual
```bash
npm run backup-db
```

## 6. Catatan Verifikasi (berdasarkan file `daftar_pemilih_tetap.xlsx` yang diberikan)

- `[DIKONFIRMASI PANITIA]` Identitas login guru/staf adalah **NIP** (bagi yang sudah memiliki) atau **NUPTK** (bagi yang belum memiliki NIP) — **bukan NIK KTP**. Contoh dari data Anda: dua guru (Meylan N. Bakari, S.Pd. dan Sri Hainun Jusuf, M.Pd.) belum memiliki NIP dan login memakai NUPTK 16 digit masing-masing. Seluruh label di aplikasi (halaman login guru, kolom tabel Data Pemilih, template import) sudah diperbarui dari "NIK" menjadi "NIP/NUPTK" agar tidak membingungkan panitia maupun guru saat hari-H. Kolom internal di database masih bernama `nik` (nama historis dari draf spesifikasi awal) — ini hanya penamaan teknis, tidak memengaruhi fungsi.
- `[TERVERIFIKASI]` Heuristik auto-deteksi mode "Gabungan" (siswa vs guru berdasarkan panjang angka identitas) sudah diuji terhadap 142 baris file Anda: 103 siswa + 39 guru, 0 baris invalid, termasuk kedua guru berNUPTK di atas terklasifikasi benar sebagai "guru" (bukan "siswa").
- `[ASUMSI]` Baris dengan jabatan seperti "Wakasek Kurikulum", "Kaprodi Tekstil" dianggap sebagai pemilih kategori "guru" (login pakai NIP/NUPTK), bukan siswa — sesuai spesifikasi awal Anda bahwa guru & staf sama-sama masuk kategori pemilih guru.

---

## 7. Keamanan yang Sudah Diimplementasikan

| Aspek | Implementasi |
|---|---|
| Session | `express-session` + `connect-sqlite3` (persisten, bertahan restart), cookie `HttpOnly`, `SameSite=Strict`, `secure` mengikuti `HTTPS_ENABLED` di `.env` (BUKAN `NODE_ENV` — lihat Bab 8) |
| Session fixation | `session.regenerate()` setiap login (admin & voter) |
| CSRF | Double-submit token (`X-CSRF-Token` header vs `session.csrfToken`), wajib di semua request state-changing |
| Rate limiting | Lapis 1: per-IP (`express-rate-limit`). Lapis 2: per-identitas (NISN/NIK/username) tersimpan di tabel `login_attempts`, lockout 15 menit setelah 5 (voter) / 8 (admin) percobaan gagal |
| Password admin | `bcrypt` cost factor 12 |
| Anti double-voting | Transaksi sinkron `db.transaction()`: `UPDATE ... SET has_voted=1 WHERE id=? AND has_voted=0` — hanya 1 request yang bisa mengubah baris dari 0→1. SQLite juga hanya mengizinkan satu writer aktif pada satu waktu (WAL mode), jadi ini aman bahkan lintas proses, bukan hanya lintas request dalam proses yang sama. |
| Privasi pilihan | Tabel `votes` **tidak menyimpan referensi ke voter** (tidak ada kolom voter_id) — sudah diverifikasi langsung dari isi database saat testing. Audit log hanya mencatat "siswa/guru id=X telah memilih", TIDAK mencatat paslon yang dipilih. |
| Upload foto | Validasi ulang via `sharp` (bukan hanya percaya mimetype header), resize maks 800x800, kompresi ke WebP, nama file diacak (bukan nama asli) |
| Import file | Validasi header, deteksi duplikat di dalam file, preview wajib sebelum commit ke database |
| Security headers | `helmet` (CSP membatasi script hanya dari domain sendiri + cdn.tailwindcss.com; Chart.js & font sudah di-vendor lokal, tidak lagi butuh cdnjs/Google Fonts) |

### Yang SENGAJA belum/tidak diimplementasikan (batasan jujur, bukan disembunyikan)

- **Dependensi eksternal untuk tampilan**: Chart.js (grafik dashboard) sudah **di-vendor lokal** (`public/js/vendor/chart.umd.js`) — tidak butuh internet. Google Fonts juga sudah dilepas, aplikasi memakai font sistem. Satu-satunya dependensi eksternal yang tersisa adalah **Tailwind Play CDN** (`cdn.tailwindcss.com`) untuk styling — jika jaringan Anda benar-benar terisolasi total (tanpa akses internet sama sekali dari komputer/HP yang dipakai memilih), halaman akan tampil tanpa styling (fungsional tapi polos). Solusi permanen: build Tailwind CSS secara statis dengan `npx tailwindcss` (butuh Node + akses npm registry sekali saat build, hasilnya file CSS statis yang tidak butuh internet lagi saat dipakai) — beri tahu saya jika Anda ingin saya siapkan build ini.
- **HTTPS/TLS**: aplikasi ini adalah aplikasi Node polos, tidak menyediakan HTTPS sendiri. Idealnya taruh di belakang reverse proxy (Nginx/Caddy) dengan sertifikat TLS, set `HTTPS_ENABLED=true` di `.env`, dan `TRUST_PROXY=true`. **Jika HTTPS benar-benar tidak tersedia** (mis. jaringan sekolah lokal tanpa domain/sertifikat), aplikasi tetap bisa dipakai dengan `HTTPS_ENABLED=false` (default) — cookie session akan dikirim tanpa flag `Secure` agar tetap berfungsi di HTTP, tapi ini berarti trafik (termasuk NISN/NIP yang diketik) tidak terenkripsi dan bisa disadap oleh siapa pun yang berada di jaringan yang sama. **Mitigasi wajib untuk skenario HTTP-only**: pastikan voting hanya dilakukan dari jaringan sekolah yang benar-benar tertutup (bukan Wi-Fi publik/terbuka), idealnya di VLAN terpisah dari jaringan tamu. Lihat Bab 8 untuk detail konfigurasi.
- **Multi-instance / clustering**: garansi anti-double-vote di atas berlaku untuk **satu proses Node** membaca satu file SQLite. Jika di-deploy dengan PM2 cluster mode atau banyak instance di belakang load balancer, SQLite tetap melindungi dari race condition write (single-writer lock), tapi throughput akan jadi bottleneck di volume sangat tinggi. Untuk skala > beberapa ribu pemilih serentak, pertimbangkan migrasi ke PostgreSQL dengan `SELECT ... FOR UPDATE`.
- **Manajemen banyak admin**: saat ini hanya 1 akun admin (superadmin) yang di-seed otomatis. Endpoint untuk membuat admin tambahan belum dibuat di UI (tabel `users` sudah mendukung banyak admin dengan role, tinggal ditambahkan endpoint CRUD jika dibutuhkan).
- **Backup otomatis**: tidak ada job backup terjadwal bawaan (belum ada cron). Backup = Snapshot = Replication adalah hal berbeda — untuk pemilihan sungguhan, minimal jalankan `npm run backup-db` (lihat Bab 5) secara berkala selama masa voting berlangsung, dan uji proses restore-nya, bukan cuma menyalin file.

---

## 8. Perbedaan Konfigurasi: Lab vs Production (HTTPS) vs Production (HTTP-only)

| | Lab / Uji Coba | Production + HTTPS (ideal) | Production HTTP-only (skenario Anda saat ini) |
|---|---|---|---|
| `NODE_ENV` | `development` | `production` | `production` |
| `HTTPS_ENABLED` | `false` | `true` | `false` — **wajib**, jangan diubah ke `true` tanpa HTTPS sungguhan (lihat peringatan di bawah) |
| HTTPS | Opsional | **Wajib** (reverse proxy + Let's Encrypt) | Tidak tersedia — mitigasi: isolasi jaringan (lihat Bab 7) |
| `SESSION_SECRET` | boleh default | **Wajib** diganti (`openssl rand -hex 32`) | **Wajib** diganti |
| `TRUST_PROXY` | `false` | `true` (jika di belakang Nginx) | `false` (kecuali juga pakai reverse proxy non-TLS) |
| Password admin default | boleh dibiarkan sementara | **Wajib** diganti sebelum data pemilih diimport | **Wajib** diganti |
| Backup DB | tidak perlu | Backup manual berkala selama masa voting + setelah voting selesai | Backup manual berkala — **lebih penting lagi** karena tidak ada lapisan HTTPS sebagai pengaman tambahan |
| Jumlah proses | 1 proses `node` cukup | 1 proses `node` di belakang Nginx | 1 proses `node`, boleh langsung tanpa reverse proxy jika jaringan sudah terisolasi |

**Peringatan penting soal `HTTPS_ENABLED`:** field ini mengontrol flag `Secure` pada cookie session. Jika Anda set `HTTPS_ENABLED=true` padahal aplikasi diakses lewat `http://` biasa, browser akan **menolak mengirim cookie sama sekali** — akibatnya login terlihat berhasil (server merespons OK) tapi halaman berikutnya selalu menganggap Anda belum login, seolah-olah bug acak yang membingungkan untuk didiagnosis. Selalu cocokkan `HTTPS_ENABLED` dengan protokol yang benar-benar dipakai browser saat mengakses aplikasi.

---

## 9. Troubleshooting

| Gejala | Kemungkinan Penyebab | Cara Cek |
|---|---|---|
| Grafik dashboard kosong/blank (angka statistik tetap muncul normal) | **[SUDAH DIPERBAIKI]** Sebelumnya Chart.js dimuat dari CDN (`cdnjs.cloudflare.com`); di jaringan yang tidak bisa menjangkau domain itu (walau domain lain seperti `cdn.tailwindcss.com` bisa), file gagal dimuat dan grafik gagal digambar tanpa pesan error yang terlihat pengguna. Sudah diganti jadi file lokal (`public/js/vendor/chart.umd.js`), tidak butuh internet lagi. | Buka DevTools (F12) → tab Console, cek ada tidaknya error merah saat memuat halaman |
| Kartu paslon tidak sejajar (mis. 3 di atas, 1 di baris bawah) | **[SUDAH DIPERBAIKI]** Grid sebelumnya pakai jumlah kolom tetap (`lg:grid-cols-3`), sehingga jumlah paslon yang tidak habis dibagi 3 akan menyisakan baris terakhir tidak penuh. Sudah diganti ke grid `auto-fit` yang otomatis menyesuaikan jumlah kolom dengan lebar layar & jumlah paslon. | - |
| Login terlihat berhasil (respons OK) tapi halaman berikutnya selalu meminta login ulang | **[SUDAH DIPERBAIKI, tapi bisa terjadi lagi jika salah konfigurasi]** `HTTPS_ENABLED=true` di `.env` padahal aplikasi diakses lewat HTTP biasa → cookie session tidak terkirim. Set `HTTPS_ENABLED=false` jika belum ada HTTPS sungguhan (lihat Bab 8) | Buka DevTools → Application → Cookies, cek apakah cookie `evoting.sid` benar-benar tersimpan setelah login |
| `CSRF_INVALID` terus-menerus | Cookie session tidak terkirim (kasus di atas), atau domain/protokol beda antara frontend & API | Sama seperti di atas |
| Foto paslon gagal upload | File > 3MB atau bukan JPG/PNG/WEBP | Cek pesan error di response, kompres/convert dulu |
| Import ditolak "Header wajib tidak ditemukan" | Nama kolom header tidak cocok (case-insensitive tapi ejaan harus sama) | Gunakan template yang disediakan di halaman Import |
| Siswa/guru tidak bisa login walau data ada | Status pemilihan bukan "berlangsung", atau status data pemilih "inactive" | Cek menu Pengaturan & Data Pemilih |
| Server tidak jalan setelah `npm install` | Modul native (`better-sqlite3`, `sharp`) gagal build di OS/arsitektur tertentu | Jalankan `npm rebuild better-sqlite3 sharp`, pastikan versi Node kompatibel |
| Sudah reset data voting / ganti password lewat script, tapi tampilan/browser masih menunjukkan data lama | Kemungkinan ada **lebih dari satu proses server berjalan** (mis. proses lama yang lupa dimatikan sebelum `pm2 start` baru), atau `.env` di-set `DB_PATH` custom yang berbeda dari yang dipakai script. Lihat Bab 5 - script maintenance sudah memuat `.env` untuk mencegah ini, tapi proses server ganda tetap bisa jadi penyebab | `pm2 describe evoting-osis` (cek `script path` & `exec cwd`), `ps aux \| grep node` (cek ada proses ganda?), `find / -name "evoting.db*" 2>/dev/null` (cek ada db ganda?) |

Command diagnosis dulu, baru command perubahan:
```bash
# 1. Cek proses & log
ps aux | grep node
tail -f /var/log/evoting/server.log   # sesuaikan lokasi log Anda

# 2. Cek isi database (read-only, aman)
node -e "const db=require('./src/db/database'); console.log(db.prepare('SELECT status FROM election_settings').get())"

# 3. Baru lakukan perubahan (mis. restart service)
pm2 restart evoting-osis   # atau systemctl restart evoting-osis
```

---

## 10. Deployment Sederhana dengan PM2 + Nginx (contoh, sesuaikan dengan environment Anda)

```bash
npm install -g pm2
pm2 start src/server.js --name evoting-osis
pm2 save
pm2 startup   # ikuti instruksi yang ditampilkan
```

Contoh reverse proxy Nginx (ringkas — sesuaikan hardening TLS/header sesuai kebijakan Anda):
```nginx
server {
    listen 443 ssl http2;
    server_name evoting.sekolah.sch.id;
    ssl_certificate     /etc/letsencrypt/live/evoting.sekolah.sch.id/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/evoting.sekolah.sch.id/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
Jangan lupa set `TRUST_PROXY=true` di `.env` agar `req.ip` (dipakai rate limiting) membaca IP asli dari header `X-Forwarded-For`, bukan IP Nginx.

### Deployment HTTP-only tanpa Nginx (jaringan sekolah lokal, tanpa domain/TLS)

Jika seperti kasus Anda saat ini — server diakses langsung lewat `http://IP-server:3000` di jaringan sekolah tanpa reverse proxy sama sekali:

```bash
# .env
NODE_ENV=production
HTTPS_ENABLED=false
TRUST_PROXY=false
SESSION_SECRET=<hasil openssl rand -hex 32>
```

```bash
npm install -g pm2
pm2 start src/server.js --name evoting-osis
pm2 save && pm2 startup
```

Tidak perlu Nginx. Pastikan saja:
1. Firewall/`ufw` di server Ubuntu hanya membuka port 3000 (atau port pilihan Anda) ke jaringan sekolah, bukan ke internet publik.
2. Jaringan yang dipakai untuk voting (Wi-Fi/kabel) terpisah dari jaringan tamu/publik — idealnya VLAN tersendiri.
3. Jalankan `npm run backup-db` sebelum & sesudah masa voting (lihat Bab 5).

---

## 11. Lisensi & Catatan

Dibuat sebagai proyek internal sekolah. Tidak ada dependensi berbayar. Semua library pihak ketiga (Express, better-sqlite3, bcrypt, sharp, dll.) adalah open source dengan lisensi MIT/ISC — cek `package.json` untuk daftar lengkap.
