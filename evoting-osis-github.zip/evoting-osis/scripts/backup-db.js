/**
 * Backup manual database SQLite. Memuat .env agar konsisten dengan DB_PATH
 * yang dipakai server.js.
 *
 * Penggunaan:
 *   node scripts/backup-db.js
 */
require('dotenv').config();
const fs = require('fs');
const path = require('path');

const dbPath = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'evoting.db');

if (!fs.existsSync(dbPath)) {
  console.error('Database tidak ditemukan di:', dbPath);
  process.exit(1);
}

const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const backupPath = path.join(path.dirname(dbPath), `evoting-backup-${stamp}.db`);
fs.copyFileSync(dbPath, backupPath);

console.log('Backup berhasil dibuat:', backupPath);
console.log('Ukuran:', (fs.statSync(backupPath).size / 1024).toFixed(1), 'KB');
