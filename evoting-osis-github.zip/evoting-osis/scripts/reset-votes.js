/**
 * Reset data voting: mengembalikan status has_voted semua pemilih ke 0 dan
 * mengosongkan tabel votes. TIDAK menyentuh data siswa/guru/paslon itu sendiri.
 *
 * PENTING: script ini memuat .env terlebih dahulu (lewat dotenv), sehingga
 * konsisten membaca DB_PATH yang sama dengan yang dipakai server.js saat
 * berjalan. Jangan pakai `node -e "..."` ad-hoc untuk operasi seperti ini -
 * kalau .env Anda punya DB_PATH custom, perintah ad-hoc bisa menulis ke file
 * database yang BERBEDA dari yang dibaca aplikasi, dan perubahan Anda
 * "menghilang" dari tampilan.
 *
 * Penggunaan:
 *   node scripts/reset-votes.js                  -> tampilkan kondisi saat ini, minta konfirmasi
 *   node scripts/reset-votes.js --yes             -> langsung eksekusi tanpa tanya (untuk otomasi)
 *   node scripts/reset-votes.js --yes --status-belum-dimulai
 *                                                  -> sekalian set status pemilihan ke "belum_dimulai"
 */
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const db = require('../src/db/database');

const args = process.argv.slice(2);
const skipConfirm = args.includes('--yes');
const alsoResetStatus = args.includes('--status-belum-dimulai');

function getDbPath() {
  return process.env.DB_PATH || path.join(__dirname, '..', 'data', 'evoting.db');
}

function printCounts(label) {
  const votes = db.prepare('SELECT COUNT(*) c FROM votes').get().c;
  const siswaVoted = db.prepare('SELECT COUNT(*) c FROM students WHERE has_voted = 1').get().c;
  const guruVoted = db.prepare('SELECT COUNT(*) c FROM teachers WHERE has_voted = 1').get().c;
  const status = db.prepare('SELECT status FROM election_settings WHERE id = 1').get().status;
  console.log(`\n-- ${label} --`);
  console.log('DB path       :', getDbPath());
  console.log('Total votes   :', votes);
  console.log('Siswa memilih :', siswaVoted);
  console.log('Guru memilih  :', guruVoted);
  console.log('Status        :', status);
  return { votes, siswaVoted, guruVoted, status };
}

function backupDb() {
  const dbPath = getDbPath();
  if (!fs.existsSync(dbPath)) {
    console.log('(Lewati backup: file database belum ada di', dbPath, ')');
    return null;
  }
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupPath = path.join(path.dirname(dbPath), `evoting-backup-sebelum-reset-${stamp}.db`);
  fs.copyFileSync(dbPath, backupPath);
  console.log('Backup dibuat :', backupPath);
  return backupPath;
}

function doReset() {
  const reset = db.transaction(() => {
    db.prepare('DELETE FROM votes').run();
    db.prepare('UPDATE students SET has_voted = 0, voted_at = NULL').run();
    db.prepare('UPDATE teachers SET has_voted = 0, voted_at = NULL').run();
    if (alsoResetStatus) {
      db.prepare(`UPDATE election_settings SET status = 'belum_dimulai', updated_at = datetime('now') WHERE id = 1`).run();
    }
  });
  reset();
}

async function main() {
  const before = printCounts('KONDISI SAAT INI');

  if (before.votes === 0 && before.siswaVoted === 0 && before.guruVoted === 0) {
    console.log('\nTidak ada data voting untuk direset (semua sudah 0). Tidak melakukan apa-apa.');
    process.exit(0);
  }

  if (!skipConfirm) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const answer = await new Promise((resolve) => {
      rl.question('\nYakin ingin RESET seluruh data voting di atas? Ketik "RESET" untuk lanjut: ', resolve);
    });
    rl.close();
    if (answer.trim() !== 'RESET') {
      console.log('Dibatalkan. Tidak ada perubahan.');
      process.exit(0);
    }
  }

  backupDb();
  doReset();
  printCounts('SETELAH RESET');
  console.log('\nSelesai. Refresh halaman dashboard/realcount di browser untuk melihat hasilnya.');
}

main();
