/**
 * Reset password admin. Memuat .env terlebih dahulu (lihat catatan di
 * reset-votes.js soal pentingnya ini).
 *
 * Penggunaan:
 *   node scripts/reset-admin-password.js <username> <password-baru>
 *
 * Contoh:
 *   node scripts/reset-admin-password.js admin RahasiaBaru123!
 */
require('dotenv').config();
const bcrypt = require('bcrypt');
const db = require('../src/db/database');

const [, , username, newPassword] = process.argv;

if (!username || !newPassword) {
  console.error('Penggunaan: node scripts/reset-admin-password.js <username> <password-baru>');
  process.exit(1);
}
if (newPassword.length < 8) {
  console.error('Password baru minimal 8 karakter.');
  process.exit(1);
}

const user = db.prepare('SELECT id, username, role FROM users WHERE username = ?').get(username);
if (!user) {
  console.error(`GAGAL: username "${username}" tidak ditemukan. Akun yang ada:`);
  console.error(db.prepare('SELECT username, role, status FROM users').all());
  process.exit(1);
}

const hash = bcrypt.hashSync(newPassword, 12);
db.prepare(`UPDATE users SET password = ?, updated_at = datetime('now') WHERE id = ?`).run(hash, user.id);

console.log(`Berhasil: password untuk username "${username}" (role: ${user.role}) sudah direset.`);
console.log('Segera login dan simpan password baru ini di tempat yang aman.');
