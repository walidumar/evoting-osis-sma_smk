require('dotenv').config();
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);

const { initSchema } = require('./db/init');
const { issueCsrfToken } = require('./middleware/csrf');
const publicRoutes = require('./routes/public');
const authVoterRoutes = require('./routes/authVoter');
const adminRoutes = require('./routes/admin');

initSchema();

const app = express();
const PORT = process.env.PORT || 3000;
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

// PENTING: secure cookie SENGAJA dipisah dari NODE_ENV. Banyak deployment sungguhan
// (mis. jaringan sekolah lokal) berjalan tanpa HTTPS ("HTTP-only production"). Jika
// secure cookie mengikuti NODE_ENV=production secara otomatis padahal tidak ada HTTPS,
// browser akan MENOLAK mengirim cookie session sama sekali -> login terlihat berhasil
// tapi sesi tidak pernah tersimpan. Set HTTPS_ENABLED=true di .env HANYA jika aplikasi
// benar-benar diakses lewat HTTPS (baik langsung maupun di belakang reverse proxy TLS).
const HTTPS_ENABLED = process.env.HTTPS_ENABLED === 'true';

// Jika di-deploy di belakang reverse proxy (Nginx/Traefik) dengan HTTPS, aktifkan ini via .env
if (process.env.TRUST_PROXY === 'true') {
  app.set('trust proxy', 1);
}

// ---------- SECURITY HEADERS ----------
// Catatan: Chart.js kini di-vendor lokal (public/js/vendor) dan Google Fonts tidak lagi
// dipakai (andalkan font sistem), supaya aplikasi tetap berfungsi penuh di jaringan
// sekolah tanpa akses internet keluar. Satu-satunya dependensi eksternal yang tersisa
// adalah Tailwind Play CDN untuk styling - lihat README bagian "Deployment Tanpa Internet"
// jika jaringan Anda benar-benar terisolasi total.
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.tailwindcss.com"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      fontSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: ["'self'"],
      // Nonaktifkan upgrade-insecure-requests: tanpa ini, browser akan memaksa semua
      // request jadi HTTPS meski server sengaja HTTP-only (lihat README - Deployment HTTP-only).
      upgradeInsecureRequests: null,
    },
  },
}));

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

// ---------- SESSION ----------
app.use(session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: path.join(__dirname, '..', 'data') }),
  name: 'evoting.sid',
  secret: process.env.SESSION_SECRET || 'GANTI_DENGAN_SECRET_ACAK_DI_ENV_PRODUCTION',
  resave: false,
  saveUninitialized: false,
  rolling: true, // perpanjang masa aktif session setiap ada aktivitas (sliding session timeout)
  cookie: {
    httpOnly: true,
    sameSite: 'strict',
    secure: HTTPS_ENABLED, // lihat catatan HTTPS_ENABLED di atas - JANGAN samakan dengan NODE_ENV
    maxAge: 20 * 60 * 1000, // 20 menit
  },
}));

// ---------- STATIC FILES ----------
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// ---------- CSRF TOKEN ENDPOINT ----------
app.get('/api/csrf-token', issueCsrfToken);

// ---------- ROUTES ----------
app.use('/api/public', publicRoutes);
app.use('/api/voter', authVoterRoutes);
app.use('/api/admin', adminRoutes);

// ---------- 404 API ----------
app.use('/api', (req, res) => {
  res.status(404).json({ ok: false, error: 'NOT_FOUND', message: 'Endpoint tidak ditemukan.' });
});

// ---------- ERROR HANDLER (multer, dsb.) ----------
app.use((err, req, res, next) => {
  console.error('[UNHANDLED_ERROR]', err);
  const message = err && err.message ? err.message : 'Terjadi kesalahan pada server.';
  res.status(err.status || 400).json({ ok: false, error: 'ERROR', message });
});

app.listen(PORT, () => {
  console.log(`E-Voting OSIS server berjalan di http://localhost:${PORT}`);
  console.log(`NODE_ENV=${process.env.NODE_ENV || 'development'}  |  HTTPS_ENABLED=${HTTPS_ENABLED} (secure cookie: ${HTTPS_ENABLED})`);
  if (!HTTPS_ENABLED) {
    console.log('PERINGATAN: berjalan tanpa HTTPS. Cookie session TIDAK diberi flag Secure agar tetap terkirim di HTTP.');
    console.log('Ini mengurangi perlindungan terhadap penyadapan jaringan - pastikan jaringan voting terisolasi/terpercaya (lihat README).');
  }
});
