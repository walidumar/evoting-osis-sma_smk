const ADMIN_MENU = [
  { href: '/admin/dashboard.html', label: 'Dashboard' },
  { href: '/admin/pemilih.html', label: 'Data Pemilih' },
  { href: '/admin/import.html', label: 'Import Data' },
  { href: '/admin/paslon.html', label: 'Paslon' },
  { href: '/admin/pengaturan.html', label: 'Pengaturan' },
  { href: '/admin/audit.html', label: 'Audit Log' },
];

function renderAdminNav() {
  const path = window.location.pathname;
  const nav = document.getElementById('adminNav');
  if (!nav) return;
  nav.innerHTML = `
    <div class="sticky top-0 z-40 flex items-center justify-between px-4 md:px-8 py-3 bg-[#0b1120]/90 backdrop-blur border-b border-white/10">
      <div class="flex items-center gap-5 overflow-x-auto">
        <span class="flex items-center gap-2 font-bold text-white whitespace-nowrap">
          <span class="w-7 h-7 rounded-lg bg-indigo-500/20 border border-indigo-400/20 flex items-center justify-center">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M9 12l2 2 4-4" stroke="#a5b4fc" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><rect x="3" y="4" width="18" height="16" rx="2" stroke="#a5b4fc" stroke-width="1.6"/></svg>
          </span>
          E-Voting OSIS <span class="text-indigo-400 font-medium hidden sm:inline">Admin</span>
        </span>
        <div class="flex gap-1">
          ${ADMIN_MENU.map(m => `<a href="${m.href}" class="px-3 py-1.5 rounded-lg text-sm whitespace-nowrap transition ${path === m.href ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/40' : 'text-slate-300 hover:bg-white/5'}">${m.label}</a>`).join('')}
        </div>
      </div>
      <button id="btnLogout" class="flex items-center gap-1.5 text-sm text-slate-400 hover:text-red-400 whitespace-nowrap transition">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
        Keluar
      </button>
    </div>
  `;
  document.getElementById('btnLogout').addEventListener('click', async () => {
    await apiPost('/api/admin/logout', {});
    window.location.href = '/admin/login.html';
  });
}

// Guard: panggil di setiap halaman admin (selain login.html) untuk memastikan sesi valid
async function guardAdmin() {
  const r = await apiGet('/api/admin/me');
  if (!r.ok) {
    window.location.href = '/admin/login.html';
    return null;
  }
  renderAdminNav();
  return r.data;
}
